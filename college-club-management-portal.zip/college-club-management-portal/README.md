# College Club Management Portal
Front-end demo for a Level 2 Fundamentals of Web Development project.

## Files
- `index.html`: webpage structure and forms
- `style.css`: styling and responsive layout
- `script.js`: sample clubs, search/filter, club details and sample members, join/leave, registration validation, event announcements

## Run
Open `index.html` in a modern browser.

## Upload to GitHub
1. Sign in at https://github.com/
2. Create a repository named `college-club-management-portal`.
3. On the repository page, choose **Add file → Upload files**.
4. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
5. Enter a commit message such as `Add College Club Management Portal`.
6. Click **Commit changes**.
7. Copy the real repository URL into your project report.

## Limitation
This is a front-end demonstration. Information is not saved to a database; sample member names are placeholders. A real deployment needs authentication, server-side validation, a backend and database.
