const clubs=[
{id:"ai",name:"AI & Coding Club",category:"Technology",info:"Coding practice, workshops and AI projects.",activities:["Coding practice","AI workshops"],members:["Sample Student 1","Sample Student 2"]},
{id:"arts",name:"Fine Arts Club",category:"Arts",info:"Drawing, design and creative activities.",activities:["Art workshops","College exhibitions"],members:["Sample Student 3","Sample Student 4"]},
{id:"service",name:"Community Service Club",category:"Social Service",info:"Volunteering and community outreach.",activities:["Awareness campaigns","Community volunteering"],members:["Sample Student 5","Sample Student 6"]}
];
const area=document.querySelector("#clubs"), detail=document.querySelector("#clubDetails"), joined=new Set();
const clubSelect=document.querySelector("#registerClub");
clubs.forEach(c=>{const o=document.createElement("option");o.value=c.id;o.textContent=c.name;clubSelect.append(o)});
function showDetails(c){
 detail.replaceChildren();const h=document.createElement("h3");h.textContent=c.name;
 const d=document.createElement("p");d.textContent=c.category+" — "+c.info;
 const ah=document.createElement("h4");ah.textContent="Activities";const ul=document.createElement("ul");
 c.activities.forEach(x=>{const li=document.createElement("li");li.textContent=x;ul.append(li)});
 const mh=document.createElement("h4");mh.textContent="Sample members";const ml=document.createElement("ul");
 c.members.forEach(x=>{const li=document.createElement("li");li.textContent=x;ml.append(li)});
 detail.append(h,d,ah,ul,mh,ml);clubSelect.value=c.id;
}
function render(){
 const q=document.querySelector("#search").value.toLowerCase().trim(),cat=document.querySelector("#category").value;
 const found=clubs.filter(c=>(c.name+" "+c.info+" "+c.category).toLowerCase().includes(q)&&(!cat||c.category===cat));
 area.replaceChildren();document.querySelector("#emptyState").hidden=found.length>0;
 found.forEach(c=>{
  const card=document.createElement("article");card.className="club-card";
  const h=document.createElement("h3");h.textContent=c.name;const catp=document.createElement("p");catp.textContent=c.category;
  const desc=document.createElement("p");desc.textContent=c.info;const actions=document.createElement("div");actions.className="actions";
  const details=document.createElement("button");details.type="button";details.textContent="View details";details.onclick=()=>showDetails(c);
  const join=document.createElement("button");join.type="button";join.textContent=joined.has(c.id)?"Leave club":"Join club";
  join.onclick=()=>{joined.has(c.id)?joined.delete(c.id):joined.add(c.id);render()};
  actions.append(details,join);card.append(h,catp,desc,actions);area.append(card);
 });
}
document.querySelector("#search").addEventListener("input",render);
document.querySelector("#category").addEventListener("change",render);
document.querySelector("#registration").addEventListener("submit",e=>{
 e.preventDefault();const name=document.querySelector("#studentName").value.trim(),email=document.querySelector("#email").value.trim(),club=clubs.find(c=>c.id===clubSelect.value);
 document.querySelector("#message").textContent=`Demo registration validated for ${name} (${email}) in ${club.name}.`;e.target.reset();
});
document.querySelector("#eventForm").addEventListener("submit",e=>{
 e.preventDefault();const title=document.querySelector("#eventTitle").value.trim();if(!title)return;
 const li=document.createElement("li");li.textContent=title;document.querySelector("#events").prepend(li);e.target.reset();
});
render();
